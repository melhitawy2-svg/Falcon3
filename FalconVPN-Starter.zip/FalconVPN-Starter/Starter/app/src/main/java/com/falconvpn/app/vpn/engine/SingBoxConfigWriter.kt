package com.falconvpn.app.vpn.engine

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Writes a temporary sing-box JSON configuration inside the app-private files directory.
 * Never log the returned path contents: the config contains the proxy password.
 */
class SingBoxConfigWriter(context: Context) {
    private val configFile = File(context.applicationContext.filesDir, "sing-box-runtime.json")

    @Synchronized
    fun write(profileJson: JSONObject): File {
        val host = profileJson.optString("host")
        val port = profileJson.optInt("port")
        val protocol = profileJson.optString("protocol", "Shadowsocks")
        require(host.isNotBlank() && port in 1..65535) { "بيانات السيرفر المحدد غير مكتملة." }

        val outbound = when (protocol.lowercase()) {
            "vless" -> {
                val uuid = profileJson.optString("uuid")
                require(uuid.isNotBlank()) { "UUID الخاص بكونفج VLESS غير موجود." }
                val item = JSONObject()
                    .put("type", "vless")
                    .put("tag", "proxy")
                    .put("server", host)
                    .put("server_port", port)
                    .put("uuid", uuid)
                val security = profileJson.optString("security", "none").lowercase()
                if (security == "tls") {
                    val tls = JSONObject().put("enabled", true)
                    profileJson.optString("sni").takeIf { it.isNotBlank() }?.let { tls.put("server_name", it) }
                    item.put("tls", tls)
                } else if (security == "reality") {
                    error("استيراد رابط VLESS مع Reality يحتاج حقول publicKey و shortId غير المتوفرة في نموذج الكونفج الحالي.")
                }
                val transport = profileJson.optString("transport", "tcp").lowercase()
                if (transport == "ws") {
                    val ws = JSONObject().put("type", "ws")
                    profileJson.optString("path").takeIf { it.isNotBlank() }?.let { ws.put("path", it) }
                    profileJson.optString("ws_host").takeIf { it.isNotBlank() }?.let {
                        ws.put("headers", JSONObject().put("Host", it))
                    }
                    item.put("transport", ws)
                } else if (transport != "tcp") {
                    error("نقل VLESS من نوع $transport تم تحليله، لكن لم تتم إضافته إلى مولّد إعدادات المحرك بعد.")
                }
                item
            }
            else -> {
                val method = profileJson.optString("method")
                val password = profileJson.optString("password")
                require(method.isNotBlank() && password.isNotEmpty()) { "بيانات Shadowsocks غير مكتملة." }
                JSONObject()
                    .put("type", "shadowsocks")
                    .put("tag", "proxy")
                    .put("server", host)
                    .put("server_port", port)
                    .put("method", method)
                    .put("password", password)
            }
        }
        val direct = JSONObject().put("type", "direct").put("tag", "direct")
        // sing-box 1.14 uses typed DNS servers; the legacy address/detour
        // server object is rejected by current versions.
        val dnsServer = JSONObject()
            .put("type", "udp")
            .put("tag", "dns-remote")
            .put("server", "1.1.1.1")
            .put("server_port", 53)
            .put("detour", "proxy")
        val config = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", JSONObject()
                .put("servers", org.json.JSONArray().put(dnsServer))
                .put("final", "dns-remote"))
            .put("inbounds", org.json.JSONArray().put(
                JSONObject()
                    .put("type", "tun")
                    .put("tag", "tun-in")
                    .put("address", org.json.JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
                    .put("auto_route", true)
                    .put("strict_route", false)
                    .put("stack", "mixed")
            ))
            .put("outbounds", org.json.JSONArray().put(outbound).put(direct))
            .put("route", JSONObject().put("final", "proxy").put("auto_detect_interface", true))

        // Atomic replacement prevents the engine from reading a partially-written file.
        val temp = File(configFile.parentFile, configFile.name + ".tmp")
        temp.writeText(config.toString(2), Charsets.UTF_8)
        if (configFile.exists() && !configFile.delete()) { temp.delete(); error("تعذر تحديث ملف إعدادات المحرك.") }
        if (!temp.renameTo(configFile)) { temp.delete(); error("تعذر تجهيز ملف إعدادات المحرك.") }
        return configFile
    }

    @Synchronized
    fun delete() {
        configFile.delete()
        File(configFile.parentFile, configFile.name + ".tmp").delete()
    }
}
